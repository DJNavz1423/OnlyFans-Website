document.getElementById('myForm').addEventListener('submit', function(e) {
  e.preventDefault();
  document.querySelector('.popup-message').classList.add('active');
});

document.querySelector('.popup-confirm').addEventListener('click', function() {
  document.querySelector('.popup-message').classList.remove('active');

});

document.querySelector('.popup-message').addEventListener('click', function() {
  document.querySelector('.popup-message').classList.remove('active');

});