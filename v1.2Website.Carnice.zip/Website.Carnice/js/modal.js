// Get URL parameters
const urlParams = new URLSearchParams(window.location.search);
const productName = decodeURIComponent(urlParams.get('name'));
const productPrice = decodeURIComponent(urlParams.get('price'));
const productImage = decodeURIComponent(urlParams.get('image'));

// DOM Elements
const productImageEl = document.getElementById('product-image');
const productNameEl = document.getElementById('product-name');
const unitPriceEl = document.getElementById('unit-price');
const totalPriceEl = document.getElementById('total-price');
const quantityInput = document.getElementById('quantity');
const paymentModal = document.getElementById('paymentModal');

// Initialize product details
productImageEl.src = productImage;
productNameEl.textContent = productName;
unitPriceEl.textContent = productPrice;

// Price calculation
let unitPrice = parseFloat(productPrice.replace(/[^0-9.]/g, ''));

function updateTotal() {
    const quantity = parseInt(quantityInput.value);
    const total = unitPrice * quantity;
    totalPriceEl.textContent = `PHP ${total.toLocaleString('en-PH', { minimumFractionDigits: 2 })}`;
}

// Quantity controls
document.querySelector('[name="plus"]').addEventListener('click', () => {
    quantityInput.value = parseInt(quantityInput.value) + 1;
    updateTotal();
});

document.querySelector('[name="minus"]').addEventListener('click', () => {
    if(quantityInput.value > 1) {
        quantityInput.value = parseInt(quantityInput.value) - 1;
        updateTotal();
    }
});

quantityInput.addEventListener('input', updateTotal);

// Purchase button click
document.querySelector('.purchase-button').addEventListener('click', () => {
    paymentModal.style.display = 'flex';
});

// Initialize total
updateTotal();

// Payment validation
function validatePayment() {
const paymentAmount = parseFloat(document.getElementById('paymentAmount').value);
const total = parseFloat(totalPriceEl.textContent.replace(/[^0-9.]/g, ''));
const messageEl = document.getElementById('paymentMessage');

if (paymentAmount >= total) {
messageEl.textContent = "Purchase successful!";
messageEl.style.color = "green";
setTimeout(() => {
    paymentModal.style.display = 'none';

    // Get current URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const name = urlParams.get('name');
    const price = urlParams.get('price');
    const image = urlParams.get('image');

    const newUrl = `buy.html?name=${encodeURIComponent(name)}&price=${encodeURIComponent(price)}&image=${encodeURIComponent(image)}`;

    window.location.href = newUrl;
}, 2000);
} else {
messageEl.textContent = "Insufficient amount!";
messageEl.style.color = "red";
}
}

// Close modal when clicking outside
window.onclick = function(event) {
    if(event.target == paymentModal) {
        paymentModal.style.display = 'none';
    }
}