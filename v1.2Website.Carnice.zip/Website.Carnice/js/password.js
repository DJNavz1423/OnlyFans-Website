var a;
function pass(){
  if(a==1){
    document.getElementById('password').type='password';
    document.getElementById('eye').src='../img/svg/eye-password-hide-svgrepo-com.svg';
    a=0;
  }
  else{
    document.getElementById('password').type='text';
    document.getElementById('eye').src='../img/svg/eye-svgrepo-com.svg';
    a=1;
  }
}