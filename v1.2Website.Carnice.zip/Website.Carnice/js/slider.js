let currentSlide = 0;
        const slides = document.querySelectorAll('.slide');
        const dots = document.querySelectorAll('.slider-dot');
        let autoSlideInterval;
        
        function showSlide(index) {
            
            slides.forEach(slide => slide.classList.remove('active'));
            dots.forEach(dot => dot.classList.remove('active'));
            
            
            slides[index].classList.add('active');
            dots[index].classList.add('active');
        }
        
        function nextSlide() {
            currentSlide = (currentSlide + 1) % slides.length;
            showSlide(currentSlide);
        }
        
        function startAutoSlide() {
            autoSlideInterval = setInterval(nextSlide, 5000); // 5 seconds
        }
        
        
        showSlide(0);
        startAutoSlide();
        
        
        dots.forEach((dot, index) => {
            dot.addEventListener('click', () => {
                clearInterval(autoSlideInterval);
                currentSlide = index;
                showSlide(currentSlide);
                startAutoSlide();
            });
        });