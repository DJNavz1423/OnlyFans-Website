// Get URL parameters
const urlParams = new URLSearchParams(window.location.search);
const productName = decodeURIComponent(urlParams.get('name'));
const productPrice = decodeURIComponent(urlParams.get('price')); // This is "PHP 600.00"
const productImage = decodeURIComponent(urlParams.get('image'));

// DOM Elements
const productImageEl = document.getElementById('product-image');
const productNameEl = document.getElementById('product-name');
const unitPriceEl = document.getElementById('unit-price');
const addToCartBtn = document.querySelector('.purchase-button');

// Initialize product details
productImageEl.src = productImage;
productNameEl.textContent = productName;
unitPriceEl.textContent = productPrice;

// Function to extract numeric value from currency string
function getPriceValue(priceString) {
    // Remove all non-numeric characters except decimal point
    const numericValue = parseFloat(priceString.replace(/[^0-9.]/g, ''));
    return isNaN(numericValue) ? 0 : numericValue;
}

// Initialize cart if it doesn't exist in sessionStorage
if (!sessionStorage.getItem('cart')) {
    sessionStorage.setItem('cart', JSON.stringify([]));
}

// Add to Cart functionality
addToCartBtn.addEventListener("click", () => {
    const product = {
        name: productName,
        price: productPrice, // Store the original formatted price
        priceValue: getPriceValue(productPrice), // Store the numeric value for calculations
        image: productImage,
        quantity: 1
    };
    
    addToCart(product);
    
    // Optional: Show confirmation message
    alert(`${productName} has been added to your cart!`);
    
    // Update cart count
    updateCartCount();
});

function addToCart(product) {
    const cart = JSON.parse(sessionStorage.getItem('cart'));
    const existingProductIndex = cart.findIndex(item => item.name === product.name);
    
    if (existingProductIndex !== -1) {
        // Product already in cart, increase quantity
        cart[existingProductIndex].quantity += 1;
    } else {
        // Add new product to cart
        cart.push(product);
    }
    
    sessionStorage.setItem('cart', JSON.stringify(cart));
}

// Function to update cart count in the header
function updateCartCount() {
    const cart = JSON.parse(sessionStorage.getItem('cart')) || [];
    const totalItems = cart.reduce((total, item) => total + item.quantity, 0);
    document.querySelector('.cart-item-count').textContent = totalItems;
}

// Initialize cart count on page load
updateCartCount();