class Product {
  constructor(name, price, image) {
      this.name = name;
      this.price = price;
      this.image = image;
  }

  createProductElement() {
      const box = document.createElement('div');
      box.className = 'box';
      box.innerHTML = `
          <div class="box-content">
              <a href="buy.html?name=${encodeURIComponent(this.name)}&price=${encodeURIComponent(this.price)}&image=${encodeURIComponent(this.image)}">
                  <div class="box-img">
                      <img src="${this.image}" alt="${this.name}">
                  </div>
                  <h3>${this.name}</h3>
                  <p>${this.price}</p>
              </a>
          </div>
      `;
      return box;
  }
}

class DeskFan extends Product {
  constructor(name, price, image) {
      super(name, price, image);
      this.category = 'Desk Fans';
  }
}

class StandFan extends Product {
  constructor(name, price, image) {
      super(name, price, image);
      this.category = 'Stand Fans';
  }
}

class WallFan extends Product {
  constructor(name, price, image) {
      super(name, price, image);
      this.category = 'Wall Fans';
  }
}

class OrbitFan extends Product {
  constructor(name, price, image) {
      super(name, price, image);
      this.category = 'Orbit Fans';
  }
}

class CeilingFan extends Product {
  constructor(name, price, image) {
      super(name, price, image);
      this.category = 'Ceiling Fans';
  }
}

class PortableFan extends Product {
  constructor(name, price, image) {
      super(name, price, image);
      this.category = 'Portable Fans';
  }
}

const products = {
  'Desk Fans': [
      new DeskFan('DF v224 Black/Pink', 'PHP 600.00', '../img/fans/desk2.png'),
      new DeskFan('DF v420 Black/Blue', 'PHP 650.00', '../img/fans/desk4.png'),
      new DeskFan('DF v12 Black/Yellow', 'PHP 750.00', '../img/fans/desk5.jpg'),
      new DeskFan('DF v90 Red', 'PHP 500.00', '../img/fans/desk1.png'),
      new DeskFan('DF v200 White/Blue', 'PHP 600.00', '../img/fans/desk3.png')
  ],
  'Stand Fans': [
      new StandFan('SF v150 White/Brown', 'PHP 950.00', '../img/fans/stand2.png'),
      new StandFan('SF v2 Black/White', 'PHP 1,000.00', '../img/fans/stand4.png'),
      new StandFan('SF v350 Black/Blue', 'PHP 800.00', '../img/fans/stand5.png'),
      new StandFan('SF v45 Black/Blue', 'PHP 800.00', '../img/fans/stand3.png'),
      new StandFan('SF v500 Green/Black', 'PHP 900.00', '../img/fans/stand1.png')
  ],
  'Wall Fans':[
      new WallFan('WF v100 Black/Yellow','PHP 670.00','../img/fans/wall2.jpg'),
      new WallFan('WF v900 Silver','PHP 970.00','../img/fans/wall1.png'),
      new WallFan('WF v680 Black','PHP 720.00','../img/fans/wall5.png'),
      new WallFan('WF v1000 White/Lime','PHP 1,120.00','../img/fans/wall3.png'),
      new WallFan('WF v333 Blue/Black','PHP 700.00','../img/fans/wall4.png')
  ],
  'Orbit Fans':[
      new OrbitFan('OF v143 White', 'PHP 750.00', '../img/fans/orbit2.png'),
      new OrbitFan('OF v4 White', 'PHP 720.00', '../img/fans/orbit4.png'),
      new OrbitFan('OF v229 Black', 'PHP 650.00', '../img/fans/orbit1.jpg'),
      new OrbitFan('OF v898 Black/Blue', 'PHP 600.00', '../img/fans/orbit3.jpg'),
      new OrbitFan('OF v137 White', 'PHP 870.00', '../img/fans/orbit5.png')
  ],
  'Ceiling Fans':[
      new CeilingFan('CF v999 Gray', 'PHP 700.00', '../img/fans/ceiling1.jpg'),
      new CeilingFan('CF v69 White/Brown', 'PHP 800.00', '../img/fans/ceiling2.png'),
      new CeilingFan('CF v1000 White', 'PHP 850.00', '../img/fans/ceiling3.png')
  ],
  'Portable Fans':[
      new PortableFan('PF v777 Black', 'PHP 350.00', '../img/fans/port1.png'),
      new PortableFan('PF v8 White', 'PHP 290.00', '../img/fans/port2.png'),
      new PortableFan('PF v56 White/Red', 'PHP 450.00', '../img/fans/port3.png')
  ]
};

const categoryButtons = document.querySelectorAll('.product-button');
const defaultDisplay = document.querySelector('.default');
const chosenCategory = document.querySelector('.chosen-category');

function handleCategoryClick(event) {
  const button = event.target;
  const category = button.textContent;
  const wasActive = button.classList.contains('active');

  categoryButtons.forEach(btn => btn.classList.remove('active'));

  if (wasActive) {
      defaultDisplay.style.display = 'grid';
      chosenCategory.style.display = 'none';
      chosenCategory.innerHTML = '';
  } else {
      button.classList.add('active');
      defaultDisplay.style.display = 'none';
      
      chosenCategory.innerHTML = '';
      products[category].forEach(product => {
          chosenCategory.appendChild(product.createProductElement());
      });
      
      chosenCategory.style.display = 'grid';
  }
}

categoryButtons.forEach(button => {
  button.addEventListener('click', handleCategoryClick);
});

chosenCategory.style.display = 'none';
